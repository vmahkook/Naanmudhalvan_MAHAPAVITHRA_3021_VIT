from django.apps import AppConfig


class MtunesConfig(AppConfig):
    name = 'MMtunes'
